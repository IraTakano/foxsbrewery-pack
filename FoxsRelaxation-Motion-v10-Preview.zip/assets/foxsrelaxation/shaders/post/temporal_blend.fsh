#version 330

uniform sampler2D CurrentSampler;
uniform sampler2D HistorySampler;
uniform sampler2D GateSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    vec4 current = texture(CurrentSampler, texCoord);
    float gate = step(0.08, texelFetch(GateSampler, ivec2(0), 0).r);
    if (gate < 0.5) {
        fragColor = current;
        return;
    }
    vec4 history = texture(HistorySampler, texCoord);
    float valid = step(0.001, history.a);
    // Fixed feedback continues to decay smoothly after movement stops.
    fragColor = vec4(mix(current.rgb, history.rgb, 0.95 * valid), current.a);
}
