#version 330

uniform sampler2D TileSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    float found = 0.0;
    for (int y = 0; y < 90 && found < 0.5; ++y) {
        for (int x = 0; x < 160; ++x) {
            if (texelFetch(TileSampler, ivec2(x, y), 0).r > 0.5) {
                found = 1.0;
                break;
            }
        }
    }
    fragColor = vec4(found, 0.0, 0.0, 1.0);
}
