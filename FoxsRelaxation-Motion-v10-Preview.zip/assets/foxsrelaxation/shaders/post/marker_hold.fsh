#version 330

uniform sampler2D RawSampler;
uniform sampler2D PreviousSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    float raw = texelFetch(RawSampler, ivec2(0), 0).r;
    float previous = texelFetch(PreviousSampler, ivec2(0), 0).r;
    // A marker can leave the camera frustum for a few frames while the
    // server moves it. Decay instead of switching the effect off at once.
    float held = raw > 0.5 ? 1.0 : previous * 0.92;
    fragColor = vec4(held, 0.0, 0.0, 1.0);
}
