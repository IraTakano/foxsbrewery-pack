#version 330

uniform sampler2D OutlineSampler;

in vec2 texCoord;
out vec4 fragColor;

// Strip even faint antialiased marker fringes after the stricter gate detects
// at least one core pixel. DARK_PURPLE is reserved for this control entity.
bool isMarkerFringe(vec4 color) {
    float purple = min(color.r, color.b);
    float peak = max(color.r, color.b);
    return color.a > 0.005 && purple > 0.018 && peak < 0.96 &&
           abs(color.r - color.b) < 0.15 + 0.24 * peak &&
           color.g < 0.055 + 0.46 * purple;
}

void main() {
    vec4 color = texture(OutlineSampler, texCoord);
    fragColor = isMarkerFringe(color) ? vec4(0.0) : color;
}
