#version 330

uniform sampler2D OutlineSampler;

in vec2 texCoord;
out vec4 fragColor;

// The reserved DARK_PURPLE team color is nominally #AA00AA. Match its hue
// through alpha and color-space variation, while rejecting white/pink glows.
bool isMarker(vec4 color) {
    float purple = min(color.r, color.b);
    float peak = max(color.r, color.b);
    return color.a > 0.025 && purple > 0.08 && peak < 0.94 &&
           abs(color.r - color.b) < 0.12 + 0.20 * peak &&
           color.g < 0.04 + 0.42 * purple;
}

void main() {
    ivec2 tile = ivec2(gl_FragCoord.xy);
    ivec2 sourceSize = textureSize(OutlineSampler, 0);
    int left = tile.x * sourceSize.x / 160;
    int right = min(sourceSize.x, max(left + 1, (tile.x + 1) * sourceSize.x / 160));
    int bottom = tile.y * sourceSize.y / 90;
    int top = min(sourceSize.y, max(bottom + 1, (tile.y + 1) * sourceSize.y / 90));

    float found = 0.0;
    // Every source pixel belongs to a tile. No downsampled point can skip a
    // one-pixel outline, even at 4K (the work is spread over 160x90 fragments).
    for (int y = bottom; y < top && found < 0.5; ++y) {
        for (int x = left; x < right; ++x) {
            if (isMarker(texelFetch(OutlineSampler, ivec2(x, y), 0))) {
                found = 1.0;
                break;
            }
        }
    }
    fragColor = vec4(found, 0.0, 0.0, 1.0);
}
