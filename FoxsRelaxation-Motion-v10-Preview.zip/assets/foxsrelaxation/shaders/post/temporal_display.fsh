#version 330

uniform sampler2D CurrentSampler;
uniform sampler2D MemorySampler;
uniform sampler2D Recent1Sampler;
uniform sampler2D Recent2Sampler;
uniform sampler2D Recent3Sampler;
uniform sampler2D GateSampler;

in vec2 texCoord;
out vec4 fragColor;

vec3 feather(sampler2D source, vec2 uv, vec2 stepUv) {
    vec3 value = texture(source, uv).rgb * 0.40;
    value += texture(source, uv + vec2( stepUv.x, 0.0)).rgb * 0.10;
    value += texture(source, uv + vec2(-stepUv.x, 0.0)).rgb * 0.10;
    value += texture(source, uv + vec2(0.0,  stepUv.y)).rgb * 0.10;
    value += texture(source, uv + vec2(0.0, -stepUv.y)).rgb * 0.10;
    value += texture(source, uv + vec2( stepUv.x,  stepUv.y)).rgb * 0.05;
    value += texture(source, uv + vec2( stepUv.x, -stepUv.y)).rgb * 0.05;
    value += texture(source, uv + vec2(-stepUv.x,  stepUv.y)).rgb * 0.05;
    value += texture(source, uv + vec2(-stepUv.x, -stepUv.y)).rgb * 0.05;
    return value;
}

void main() {
    vec4 current = texture(CurrentSampler, texCoord);
    float gate = step(0.08, texelFetch(GateSampler, ivec2(0), 0).r);
    if (gate < 0.5) {
        fragColor = current;
        return;
    }

    vec2 pixelSize = 1.0 / vec2(textureSize(CurrentSampler, 0));
    vec2 stepUv = pixelSize * 2.0;
    vec4 recent1 = texture(Recent1Sampler, texCoord);
    vec4 recent2 = texture(Recent2Sampler, texCoord);
    vec4 recent3 = texture(Recent3Sampler, texCoord);

    // Raw frames remain separate from the recursive haze. Fixed weights
    // avoid the full-screen pulse of a fluctuating motion estimate.
    vec3 one = mix(current.rgb, feather(Recent1Sampler, texCoord, stepUv),
                   step(0.001, recent1.a));
    vec3 two = mix(current.rgb, feather(Recent2Sampler, texCoord, stepUv),
                   step(0.001, recent2.a));
    vec3 three = mix(current.rgb, feather(Recent3Sampler, texCoord, stepUv),
                     step(0.001, recent3.a));
    vec3 trail = one * 0.45 + two * 0.35 + three * 0.20;

    vec3 haze = mix(current.rgb,
                    feather(MemorySampler, texCoord, stepUv), 0.40);
    fragColor = vec4(mix(haze, trail, 0.50), current.a);
}
