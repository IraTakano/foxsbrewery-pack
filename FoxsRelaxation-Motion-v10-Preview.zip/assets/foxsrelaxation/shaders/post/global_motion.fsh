#version 330

uniform sampler2D CurrentSampler;
uniform sampler2D HistorySampler;
uniform sampler2D PreviousSampler;
uniform sampler2D GateSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    float gate = step(0.08, texelFetch(GateSampler, ivec2(0), 0).r);
    if (gate < 0.5) {
        fragColor = vec4(0.0, 0.0, 0.0, 1.0);
        return;
    }

    // One value controls the whole world, so quiet areas soften together
    // with high-contrast moving edges. This estimates frame change, not
    // camera velocity or motion vectors.
    float changed = 0.0;
    for (int y = 0; y < 14; ++y) {
        for (int x = 0; x < 24; ++x) {
            vec2 uv = (vec2(float(x), float(y)) + 0.5) / vec2(24.0, 14.0);
            vec3 delta = abs(texture(CurrentSampler, uv).rgb -
                             texture(HistorySampler, uv).rgb);
            float peak = max(delta.r, max(delta.g, delta.b));
            changed += smoothstep(0.008, 0.090, peak);
        }
    }
    float raw = clamp(changed / (24.0 * 14.0) * 3.0, 0.0, 1.0);
    float previous = texelFetch(PreviousSampler, ivec2(0), 0).r;
    float activity = max(mix(previous, raw, 0.48), previous * 0.90);
    fragColor = vec4(activity, 0.0, 0.0, 1.0);
}
