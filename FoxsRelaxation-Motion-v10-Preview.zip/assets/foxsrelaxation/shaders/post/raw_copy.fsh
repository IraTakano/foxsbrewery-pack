#version 330

uniform sampler2D InSampler;

in vec2 texCoord;
out vec4 fragColor;

void main() {
    // Alpha distinguishes an unwritten persistent target from a black frame.
    fragColor = vec4(texture(InSampler, texCoord).rgb, 1.0);
}
