FOX'S BREWERY RESOURCE PACK — MINECRAFT JAVA 26.2

This pack renders the liquid inside active brewery cauldrons with Minecraft's
animated water texture and the exact RGB color of the closest recipe.

Installation:
1. Upload the ZIP itself to a direct HTTPS download URL.
2. Put that URL in plugins/FoxsBrewery/config.yml at resource-pack.url.
3. Keep the release SHA-1 value already supplied in config.yml.
4. Fully restart the server. Do not use /reload.

The plugin requests the pack from every player and only reveals the custom
liquid surface after the client reports that the pack loaded successfully.
