FOXTOPIA COMBINED RESOURCE PACK — MINECRAFT JAVA 26.2

This pack contains Fox's Brewery cauldron surfaces, CustomFishing items, Willy's
shop icons, and the original four-piece fisherman outfit.

Installation:
1. Upload the ZIP itself to a direct HTTPS download URL.
2. Put that URL in plugins/FoxsBrewery/config.yml at resource-pack.url.
3. Compute the SHA-1 of this exact ZIP and put it in resource-pack.sha1.
4. Fully restart the server. Do not use /reload.

The plugin requests the pack from every player and only reveals the custom
liquid surface after the client reports that the pack loaded successfully.
