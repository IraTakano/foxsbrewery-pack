PattingYou resource pack for Minecraft Java 26.2.

Upload this ZIP without extracting it. The direct URL must return the ZIP bytes,
not an HTML download page. The plugin's default config expects:
https://raw.githubusercontent.com/IraTakano/foxsbrewery-pack/main/PattingYou-ResourcePack-26.2.zip
